import React from "react";

const TakaIcon = () => {
  return <p className='ms-1'> ৳ </p>;
};

export default TakaIcon;
